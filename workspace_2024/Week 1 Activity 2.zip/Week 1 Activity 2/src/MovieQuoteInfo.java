//Julian Rivas January 9th Activity 2 Wk 1
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("In an investigation details matter");
		System.out.println("Jack Reacher");
		System.out.println("Reacher");
		System.out.println("2023");

	}

}
