// Julian Rivas January 9th Assigment 1 Wk 1
public class Triangle {

	public static void main(String[] args) {
		System.out.println("      T ");
		System.out.println("     TTT");
		System.out.println("    TTTTT");
		System.out.println("   TTTTTTT");
		System.out.println("  TTTTTTTTT");
		System.out.println(" TTTTTTTTTTTT");
		System.out.println("TTTTTTTTTTTTTTT");

	}

}
