// Julian Rivas Practice January 9th 
public class Hello {

	public static void main(String[] args) {
		System.out.println("Hello from julian");
		System.out.println("Hello from julian again");
		

	}

}
