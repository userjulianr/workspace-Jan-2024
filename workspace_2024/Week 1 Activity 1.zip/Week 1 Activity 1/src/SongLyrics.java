// Julian Rivas January 9th Activity 1 Wk 1
public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("One of one, I'm in the zone right now");
		System.out.println("Tell me, am I still? Mm");
		System.out.println("Tellin' you just how I feel right now");
		
		System.out.println("Artist: Travis Scott");
		System.out.println("Album: Utopia");
		
		
		

	}

}
 